# Refurbish & Reforest — Hero Page Mockup

> Quick mockup of a hero page and first sections for the laptop donation & tree-planting project.

## What’s inside

- `index.html` — a static HTML page with:
  - sticky header with simple navigation,
  - main hero section (two columns: copy + visual),
  - "How it works" section,
  - impact section (affordable repairs + reuse),
  - data security section (NIST SP 800-88),
  - simple CTA form for donation requests,
  - footer.
- `styles.css` — handcrafted responsive CSS with a clean, modern look.
- `copy.txt` — all key English copy used on the page in one place.
- `canva-hero-illustration-prompt.txt` — an AI prompt you can paste into Canva (or another AI image tool) to generate a matching hero illustration.

The page is designed as a **front-door hero** for an English-only site: no language switcher is included.

## How to view

Just open `index.html` in any modern browser.

No build step, no dependencies.

## How to use with Lovable

1. Use this page as a visual + content reference.
2. In Lovable, create a new project (for example, Next.js or React).
3. Ask Lovable to:
   - reproduce the layout and styles from this mockup,
   - keep the same structure of sections and IDs (`#how-it-works`, `#impact`, `#security`, `#donate-form`),
   - wire the CTA form to your backend or form provider when ready.

---

## Notes (RU)

- Страница полностью на английском, как вы и просили.
- Hero-блок соответствует вашей концепции: responsible recycling, доступный ремонт за счёт б/у деталей, **1 laptop = 1 tree**, плюс блок про безопасность данных по NIST SP 800-88.
- Верстка адаптивная (desktop → mobile), без сторонних библиотек.
